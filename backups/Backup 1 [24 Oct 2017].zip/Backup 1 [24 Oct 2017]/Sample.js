audioBrush.Sample = function(length) {
    this.buffer = new Float32Array(length);
    this.sampleRate = 44100;
    //this.bitDepth = 16;
    
    this.max = 0.9;
    //this.max = 32767 - 64; // minus 64 for headroom
    
}

audioBrush.Sample.prototype.__defineGetter__("durationInSamples", function() {
    return this.buffer.length;
});
audioBrush.Sample.prototype.__defineGetter__("durationInSeconds", function() {
    return this.durationInSamples/this.sampleRate;
});
audioBrush.Sample.prototype.containsTime = function(t) {
    return t > 0 && t < this.durationInSamples;
}

audioBrush.Sample.prototype.rms = function(from, to) {
    if(from == undefined) {
        from = 0;
    }
    if(to == undefined) {
        to = this.durationInSamples;
    }
    
    var sum = 0;
    for(var t=Math.floor(from); t<to; t++) {
        sum += Math.pow(this.deScale(this.buffer[t]), 2);
    }
    
    var mean = sum / (to-from);
    
    return Math.sqrt(mean);
}
audioBrush.Sample.prototype.peak = function(from, to) {
    if(from == undefined) {
        from = 0;
    }
    if(to == undefined) {
        to = this.durationInSamples;
    }
    
    var peak = 0;
    for(var t=Math.floor(from); t<to; t++) {
        var A = Math.abs(this.A(t));
        if(A > peak) {
            peak = A;
        }
    }
    
    return peak;
}

audioBrush.Sample.prototype.scale = function(n) {
    return n*this.max;
}
audioBrush.Sample.prototype.deScale = function(n) {
    return n/this.max;
}

audioBrush.Sample.prototype.A = function(t) {
    // return deScaled sample value at value t, approximating linearly for non-integer values of t
    if(t<0 || t>this.durationInSamples) {
        throw "attempt to read sample that does not exist";
    }
    if(t%1 == 0) {
        return this.deScale(this.buffer[t]);
    } else {
        var pre = this.buffer[Math.floor(t)];
        var nex = this.buffer[Math.ceil(t)];
        var A = pre + (nex-pre)*(t%1);
        return this.deScale(A);
    }
}
audioBrush.Sample.prototype.setA = function(t, A) {
    // set scaled sample value at time t
    if(t<0 || t>this.durationInSamples) {
        throw "attempt to write saple that does not exist";
    }
    this.buffer[t] = this.scale(A);
}

audioBrush.Sample.prototype.play = function() {
    var ctx = audioBrush.playback.ctx;
    var buffer = ctx.createBuffer(2, this.durationInSamples, this.sampleRate);
    
    for(var channel=0; channel<buffer.numberOfChannels; channel++) {
        var data = buffer.getChannelData(channel);
        for(var t=0; t<data.length; t++) {
            data[t] = this.A(t);
        }
    }
    
    var source = ctx.createBufferSource();
    source.buffer = buffer;
    
    source.connect(audioBrush.playback.master);
    source.start();
}

audioBrush.Sample.prototype.loadFromFile = function(filename) {
    var request = new XMLHttpRequest();
    request.open("get", filename, true);
    request.responseType = "arraybuffer";
    request.sample = this;
    request.onload = function() {
        audioBrush.playback.ctx.decodeAudioData(this.response).then(function(buffer) {
            buffer = buffer.getChannelData(0);
            this.sample.buffer = buffer;
        }.bind(this));
    }
    request.send();
}