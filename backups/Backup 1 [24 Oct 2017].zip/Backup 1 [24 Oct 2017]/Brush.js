audioBrush.Brush = function() {
    this.xL = -250; // a negative number
    this.xR = 250;
    this.scaleX = 1;
    this.hardness = 1;
    
    this.f = function(dX) {
        // should be a normal distribution
        return 1/Math.sqrt(Math.pow(dX,2)/10+1);
    }
}

/*audioBrush.Brush.prototype.apply = function(x, y, disp, tool) {
    var xL = x + this.xL;
    var xR = x + this.xR;
    
    var tL = disp.tAtX(xL);
    var tR = disp.tAtX(xR);
    
    var relY = 1 - y/disp.box.height;
    for(var t=Math.floor(tL); t<=tR; t++) {
        var xB = disp.xAtT(t);
        var dX = xB - x;
        if(this.scaleX != undefined) {
            dX *= this.scaleX;
        }
        var I = this.f(dX);
        
        var dry = disp.sample.A(t);
        var wet = tool.y(dry, relY);
        var mix = I*wet + (1-I)*dry;
        disp.sample.setA(mix, t);
    }
}*/

audioBrush.Brush.prototype.makeShape = function(x, y, disp) {
    // return an intensity/Time map
    // Array must be ordered!
    var xL = x + this.xL;
    var xR = x + this.xR;
    
    tL = disp.tAtX(xL);
    tR = disp.tAtX(xR);
    
    var relY = 1 - y/disp.box.height;
    
    var shape = new Array();
    for(var t=Math.floor(tL); t<tR; t++) {
        if(!disp.sample.containsTime(t)) {
            continue;
        }
        
        var xi = disp.xAtT(t);
        var dX = xi - x;
        if(this.scaleX != undefined) {
            dX *= this.scaleX;
        }
        var I = this.f(dX) * this.hardness;
        
        shape[t] = I;
    }
    
    return shape;
}

audioBrush.Brush.prototype.drawPreview = function(x, y, disp) {
    var ctx = disp.ctx;
    
    var xL = x + this.xL;
    var xR = x + this.xR;
    var yi, yT, yB, dX, I;
    for(var xi=Math.floor(xL); xi<xR; xi+=3) {
        dX = xi-x;
        I = this.f(dX) * this.hardness;
        
        yi = disp.graph[xi];
        yT = yi-30;
        if(disp.graph2 != undefined) {
            yB = disp.graph2[xi];
        } else {
            yB = yi;
        }
        yB += 30;
        
        ctx.globalAlpha = I *3/4 + 0.2;
        ctx.beginPath();
        ctx.strokeStyle = "#f0f";
        ctx.moveTo(xi, yT);
        ctx.lineTo(xi, yB);
        ctx.stroke();
        
        ctx.globalAlpha = 1;
        
    }
    
    disp.brushPreviewDrawn = true;
}