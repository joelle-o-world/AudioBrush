audioBrush.playback = new Object();

audioBrush.playback.ctx = new AudioContext();
audioBrush.playback.master = audioBrush.playback.ctx.createGain();
audioBrush.playback.master.connect(audioBrush.playback.ctx.destination);

audioBrush.playback.openSample = function(filename) {
    var request = new XMLHttpRequest();
    request.open("get", filename, true);
    request.responseType = "arraybuffer";
    request.onload = function() {
        audioBrush.playback.ctx.decodeAudioData(this.response).then(function(buffer) {
            buffer = buffer.getChannelData(0);
            console.log(this);
        }.bind(this));
    }
    request.send();
}